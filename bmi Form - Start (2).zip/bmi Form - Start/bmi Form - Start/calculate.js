const express=require("express");
const app=express();
app.use(express.static("public"));
app.set('view engine','ejs')
const bodyParser=require("body-parser");

app.use(bodyParser.urlencoded({extended:true}))

app.get("/",function(req,res){
   // res.sendFile(__dirname+"/bmi.html")
    // res.render("bmi");
    // res.render(__dirname+"/views/bmi.ejs")

    res.render('bmi',{result:""})
});

app.post("/",function(req,res){

    var n=Number(req.body.age);
    var w=Number(req.body.weight);
    var h=Number(req.body.height);
     
    var result= [w/h/h]*10000;



    res.render('bmi',{result:"Your BMI Result is"+result.toFixed(2)})
});

app.listen(3000,function(){
    console.log("server started on port 3000")
})